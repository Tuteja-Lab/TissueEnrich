## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  fig.width=8, fig.height=5
)

## ----eval=TRUE-----------------------------------------------------------
library(TissueEnrich)
library(dplyr)
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-teEnrichment(inputGenes = inputGenes,geneFormat=2)

## ----eval=TRUE-----------------------------------------------------------
library(ggplot2)
ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
      geom_bar(stat = 'identity')+
      labs(x='', y = '-LOG10(P-Value)')+
      theme_bw()+
      theme(legend.position="none")+
      theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

## ----eval=TRUE-----------------------------------------------------------
library(tidyr)
exp<-output[[2]][["Placenta"]][[1]]
exp$Gene<-row.names(exp)
exp<-exp %>% gather(Tissue=1:(ncol(exp)-1))

ggplot(exp, aes(key, Gene)) + geom_tile(aes(fill = value),
     colour = "white") + scale_fill_gradient(low = "white",
     high = "steelblue")+
     labs(x='', y = '')+
      theme_bw()+
      guides(fill = guide_legend(title = "Log2(TPM)"))+
      #theme(legend.position="none")+
      theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())


## ----eval=TRUE-----------------------------------------------------------
groupInf<-output[[2]][["Placenta"]][[2]]
print(head(groupInf))

## ----eval=TRUE-----------------------------------------------------------
print(output[[3]])

## ----eval=TRUE-----------------------------------------------------------
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-teEnrichment(inputGenes = inputGenes,rnaSeqDataset = 3, organism = 1, geneFormat=2)
ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
      geom_bar(stat = 'identity')+
      labs(x='', y = '-LOG10(P-Value)')+
      theme_bw()+
      theme(legend.position="none")+
      theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

## ----eval=TRUE-----------------------------------------------------------
library(TissueEnrich)
data<-system.file("extdata", "test.expressiondata.txt", package = "TissueEnrich")
expressionData<-read.table(data,header=TRUE,row.names=1,sep='\t')
TSgenes<-teGeneRetrieval(expressionData)
head(TSgenes)

## ----eval=FALSE----------------------------------------------------------
#  genes<-system.file("extdata", "inputGenesEnsembl.txt", package = "TissueEnrich")
#  inputGenes<-scan(genes,character())
#  output<-teEnrichmentCustom(inputGenes,TSgenes)
#  ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
#        geom_bar(stat = 'identity')+
#        labs(x='', y = '-LOG10(P-Value)')+
#        theme_bw()+
#        theme(legend.position="none")+
#        theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
#        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

