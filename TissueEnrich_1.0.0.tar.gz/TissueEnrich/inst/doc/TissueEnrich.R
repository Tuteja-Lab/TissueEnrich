## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE----------------------------------------------------------
#  library(TissueEnrich)
#  data<-system.file("extdata", "combined-proteincodingGenedataCombine.txt", package = "TissueEnrich")
#  expressionData<-read.table(data,header=TRUE,row.names=1,sep='\t')
#  TSgenes<-tissueSpecificGenesRetrieval(expressionData)
#  head(TSgenes)

## ----eval=TRUE,warning=FALSE---------------------------------------------
library(TissueEnrich)
library(tidyverse)
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-tissueSpecificGeneEnrichment(inputGenes = inputGenes,geneFormat=2)

## ----eval=TRUE,warning=FALSE---------------------------------------------
library(plotly)
plot_ly(output[[1]], x = ~reorder(Tissue,-Log10PValue), y = ~Log10PValue, type = "bar", source = "select", color = ~Tissue, hoverinfo = 'text',width = "100%",height = 700,
            text = ~paste('</br> Tissue Name: ',
                          Tissue,'</br> -Log10(P-Value): ', Log10PValue,'</br> Tissue Specific Genes: ', Tissue.Specific.Genes)) %>% layout(autosize = TRUE,margin = list(b = 150),xaxis = list(title = "",tickangle = 315), yaxis = list(title = "-Log10(P-Value)"),showlegend = FALSE)

## ----eval=TRUE,warning=FALSE---------------------------------------------
print("Placenta specific genes found in input genes are:")
print(output[[2]][["Placenta"]])

## ----eval=TRUE,warning=FALSE---------------------------------------------
print("Input genes not found in our dataset are:")
print(output[[3]])

## ----echo=FALSE----------------------------------------------------------
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-tissueSpecificGeneEnrichment(inputGenes = inputGenes,rnaSeqDataset = 4, organism = 1, geneFormat=2,isHomolog = TRUE)
plot_ly(output[[1]], x = ~reorder(Tissue,-Log10PValue), y = ~Log10PValue, type = "bar", source = "select", color = ~Tissue, hoverinfo = 'text',width = "100%",height = 700,
            text = ~paste('</br> Tissue Name: ',
                          Tissue,'</br> -Log10(P-Value): ', Log10PValue,'</br> Tissue Specific Genes: ', Tissue.Specific.Genes)) %>% layout(autosize = TRUE,margin = list(b = 150),xaxis = list(title = "",tickangle = 315), yaxis = list(title = "-Log10(P-Value)"),showlegend = FALSE)

## ----eval=FALSE,warning=FALSE--------------------------------------------
#  data<-system.file("extdata", "combined-proteincodingGenedataCombine.txt", package = "TissueEnrich")
#  expressionData<-read.table(data,header=TRUE,row.names=1,sep='\t')
#  TSgenes<-tissueSpecificGenesRetrieval(expressionData)
#  genes<-system.file("extdata", "inputGenesEnsembl.txt", package = "TissueEnrich")
#  inputGenes<-scan(genes,character())
#  output<-tissueSpecificGeneEnrichmentCustom(inputGenes,TSgenes)
#  plot_ly(output[[1]], x = ~reorder(Tissue,-Log10PValue), y = ~Log10PValue, type = "bar", source = "select", color = ~Tissue, hoverinfo = 'text',width = "100%",height = 700,
#              text = ~paste('</br> Tissue Name: ',
#                            Tissue,'</br> -Log10(P-Value): ', Log10PValue,'</br> Tissue Specific Genes: ', Tissue.Specific.Genes)) %>% layout(autosize = TRUE,margin = list(b = 150),xaxis = list(title = "",tickangle = 315), yaxis = list(title = "-Log10(P-Value)"),showlegend = FALSE)

