## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  fig.width=7, fig.height=5
)

## ----eval=TRUE-----------------------------------------------------------
library(TissueEnrich)
data<-system.file("extdata", "test.expressiondata.txt", package = "TissueEnrich")
expressionData<-read.table(data,header=TRUE,row.names=1,sep='\t')
TSgenes<-teGeneRetrieval(expressionData)
head(TSgenes)

## ----eval=TRUE-----------------------------------------------------------
library(TissueEnrich)
library(dplyr)
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-teEnrichment(inputGenes = inputGenes,geneFormat=2)

## ----eval=TRUE-----------------------------------------------------------
library(ggplot2)
ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
      geom_bar(stat = 'identity')+
      labs(x='', y = '-LOG10(P-Value)')+
      theme_bw()+
      theme(legend.position="none")+
      theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

## ----eval=TRUE-----------------------------------------------------------
print("Placenta specific genes found in input genes are:")
print(output[[2]][["Placenta"]])

## ----eval=TRUE-----------------------------------------------------------
print("Input genes not found in our dataset are:")
print(output[[3]])

## ----eval=TRUE-----------------------------------------------------------
genes<-system.file("extdata", "inputGenes.txt", package = "TissueEnrich")
inputGenes<-scan(genes,character())
output<-teEnrichment(inputGenes = inputGenes,rnaSeqDataset = 3, organism = 1, geneFormat=2,isHomolog = TRUE)
ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
      geom_bar(stat = 'identity')+
      labs(x='', y = '-LOG10(P-Value)')+
      theme_bw()+
      theme(legend.position="none")+
      theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

## ----eval=FALSE----------------------------------------------------------
#  data<-system.file("extdata", "test.expressiondata.txt", package = "TissueEnrich")
#  expressionData<-read.table(data,header=TRUE,row.names=1,sep='\t')
#  TSgenes<-teGeneRetrieval(expressionData)
#  genes<-system.file("extdata", "inputGenesEnsembl.txt", package = "TissueEnrich")
#  inputGenes<-scan(genes,character())
#  output<-teEnrichmentCustom(inputGenes,TSgenes)
#  ggplot(output[[1]],aes(x=reorder(Tissue,-Log10PValue),y=Log10PValue,label = Tissue.Specific.Genes,fill = Tissue))+
#        geom_bar(stat = 'identity')+
#        labs(x='', y = '-LOG10(P-Value)')+
#        theme_bw()+
#        theme(legend.position="none")+
#        theme(plot.title = element_text(hjust = 0.5,size = 20),axis.title = element_text(size=15))+
#        theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),panel.grid.major= element_blank(),panel.grid.minor = element_blank())

