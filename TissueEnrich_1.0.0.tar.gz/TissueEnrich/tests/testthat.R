library(testthat)
library(TissueEnrich)

test_check("TissueEnrich")
